const SOCKET_URL = "ws://127.0.0.1:8765";
const RECONNECT_MS = 2000;
const KEEPALIVE_MS = 20000;

let socket = null;
let keepalive = null;

function ensureConnected() {
  if (!socket || socket.readyState === WebSocket.CLOSING || socket.readyState === WebSocket.CLOSED) connect();
}

function connect() {
  if (socket && socket.readyState === WebSocket.CONNECTING) return;
  socket = new WebSocket(SOCKET_URL);
  socket.onopen = () => {
    keepalive = setInterval(() => {
      if (socket && socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify({ ping: 1 }));
    }, KEEPALIVE_MS);
  };
  socket.onmessage = (event) => {
    let message;
    try {
      message = JSON.parse(event.data);
    } catch {
      return;
    }
    if (message.action || message.gesture) dispatch(message);
  };
  const retry = () => {
    clearInterval(keepalive);
    socket = null;
    setTimeout(ensureConnected, RECONNECT_MS);
  };
  socket.onclose = retry;
  socket.onerror = () => socket && socket.close();
}

async function dispatch({ action, gesture }) {
  const tabs = await chrome.tabs.query({ url: "https://www.instagram.com/*" });
  const target =
    tabs.find((t) => t.url.includes("/reels/") && t.active) ||
    tabs.find((t) => t.url.includes("/reels/")) ||
    tabs.find((t) => t.active);
  if (!target) return;
  chrome.tabs.sendMessage(target.id, { action, gesture }).catch(() => {});
}

chrome.alarms.create("reconnect", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(ensureConnected);
chrome.runtime.onStartup.addListener(ensureConnected);
chrome.runtime.onInstalled.addListener(ensureConnected);
chrome.runtime.onMessage.addListener((message) => {
  if (message && message.wake) ensureConnected();
});

ensureConnected();
