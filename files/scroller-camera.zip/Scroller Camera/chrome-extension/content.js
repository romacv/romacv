(() => {
  const TAG = "[ScrollerCamera]";
  const NEXT = /next|далее|следующ|navigate to next/i;
  const PREV = /previous|назад|предыдущ/i;

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && r.bottom > 0 && r.top < innerHeight;
  }

  function labelOf(el) {
    const parts = [el.getAttribute("aria-label"), el.getAttribute("title")];
    el.querySelectorAll("svg[aria-label], svg title").forEach((n) =>
      parts.push(n.getAttribute("aria-label") || n.textContent)
    );
    return parts.filter(Boolean).join(" ");
  }

  function clickButton(pattern) {
    const candidates = document.querySelectorAll("button, [role=button]");
    for (const el of candidates) {
      if (isVisible(el) && pattern.test(labelOf(el))) {
        el.click();
        return true;
      }
    }
    return false;
  }

  function mostVisibleVideo() {
    let best = null;
    let bestArea = 0;
    for (const v of document.querySelectorAll("video")) {
      const r = v.getBoundingClientRect();
      const w = Math.max(0, Math.min(r.right, innerWidth) - Math.max(r.left, 0));
      const h = Math.max(0, Math.min(r.bottom, innerHeight) - Math.max(r.top, 0));
      if (w * h > bestArea) {
        bestArea = w * h;
        best = v;
      }
    }
    return best;
  }

  function scrollableAncestor(el) {
    for (let n = el && el.parentElement; n; n = n.parentElement) {
      const overflow = getComputedStyle(n).overflowY;
      if ((overflow === "auto" || overflow === "scroll") && n.scrollHeight > n.clientHeight) return n;
    }
    return null;
  }

  function scrollReel(direction) {
    const video = mostVisibleVideo();
    const container = scrollableAncestor(video);
    if (!container) return false;
    container.scrollBy({ top: direction * container.clientHeight, behavior: "smooth" });
    return true;
  }

  function pressKey(direction) {
    const key = direction > 0 ? "ArrowDown" : "ArrowUp";
    const target = document.activeElement || document.body;
    target.dispatchEvent(new KeyboardEvent("keydown", { key, code: key, bubbles: true, cancelable: true }));
  }

  function flip(direction) {
    if (clickButton(direction > 0 ? NEXT : PREV)) return console.debug(TAG, "button");
    if (scrollReel(direction)) return console.debug(TAG, "scroll");
    pressKey(direction);
    console.debug(TAG, "key");
  }

  chrome.runtime.onMessage.addListener((message) => {
    const action = message.action || (message.gesture === "up" ? "next" : message.gesture === "down" ? "prev" : null);
    if (action === "next") flip(1);
    else if (action === "prev") flip(-1);
  });

  const wake = () => {
    try {
      chrome.runtime.sendMessage({ wake: 1 }).catch(() => {});
    } catch {}
  };
  wake();
  setInterval(() => {
    if (document.visibilityState === "visible") wake();
  }, 20000);
})();
